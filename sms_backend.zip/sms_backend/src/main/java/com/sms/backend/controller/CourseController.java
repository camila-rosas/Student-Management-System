package com.sms.backend.controller;

import com.sms.backend.dto.CourseDto;
import com.sms.backend.dto.CourseRequest;
import com.sms.backend.service.CourseService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseController {
    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @GetMapping
    public List<CourseDto> getCourses() {
        return courseService.getAllCourses();
    }

    @GetMapping("/search")
    public List<CourseDto> search(@RequestParam String keyword) {
        return courseService.search(keyword);
    }

    @GetMapping("/filter")
    public List<CourseDto> filter(@RequestParam String type) {
        return courseService.filter(type);
    }

    @GetMapping("/available")
    public List<CourseDto> available() {
        return courseService.filter("open");
    }

    @PostMapping
    @PreAuthorize("hasRole('REGISTRAR') or hasRole('ADMIN')")
    public CourseDto create(@RequestBody CourseRequest request) {
        return courseService.create(request);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('REGISTRAR') or hasRole('ADMIN')")
    public CourseDto update(@PathVariable Long id, @RequestBody CourseRequest request) {
        return courseService.update(id, request);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('REGISTRAR') or hasRole('ADMIN')")
    public void delete(@PathVariable Long id) {
        courseService.delete(id);
    }
}
