package com.sms.backend.service;

import com.sms.backend.dto.CourseDto;
import com.sms.backend.dto.StudentDto;
import com.sms.backend.entity.Account;
import com.sms.backend.repository.AccountRepository;
import com.sms.backend.repository.CourseRepository;
import com.sms.backend.repository.RegistrationRepository;
import com.sms.backend.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReportService {
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    private final RegistrationRepository registrationRepository;
    private final AccountRepository accountRepository;
    private final DtoMapper mapper;

    public ReportService(StudentRepository studentRepository, CourseRepository courseRepository,
                         RegistrationRepository registrationRepository, AccountRepository accountRepository,
                         DtoMapper mapper) {
        this.studentRepository = studentRepository;
        this.courseRepository = courseRepository;
        this.registrationRepository = registrationRepository;
        this.accountRepository = accountRepository;
        this.mapper = mapper;
    }

    public Map<String, Object> summary() {
        List<StudentDto> students = studentRepository.findAll().stream().map(mapper::toStudentDto).toList();
        List<CourseDto> courses = courseRepository.findAll().stream().map(mapper::toCourseDto).toList();
        int totalCapacity = courses.stream().mapToInt(CourseDto::getEnrollmentLimit).sum();
        int totalEnrollments = courses.stream().mapToInt(CourseDto::getEnrolledCount).sum();
        double totalRevenue = accountRepository.findAll().stream().mapToDouble(Account::getTotalCharges).sum();
        double totalCollected = accountRepository.findAll().stream().mapToDouble(Account::getTotalPayments).sum();
        double outstanding = accountRepository.findAll().stream().mapToDouble(Account::getCurrentBalance).sum();

        Map<String, Integer> utilizationBuckets = new HashMap<>();
        utilizationBuckets.put("full", 0);
        utilizationBuckets.put("high", 0);
        utilizationBuckets.put("medium", 0);
        utilizationBuckets.put("low", 0);
        courses.forEach(c -> {
            int rate = c.getEnrollmentLimit() == 0 ? 0 : Math.round((float) c.getEnrolledCount() / c.getEnrollmentLimit() * 100);
            if (rate >= 100) utilizationBuckets.compute("full", (k, v) -> v + 1);
            else if (rate >= 75) utilizationBuckets.compute("high", (k, v) -> v + 1);
            else if (rate >= 50) utilizationBuckets.compute("medium", (k, v) -> v + 1);
            else utilizationBuckets.compute("low", (k, v) -> v + 1);
        });

        Map<String, Integer> balanceDistribution = new HashMap<>();
        balanceDistribution.put("zero", 0);
        balanceDistribution.put("low", 0);
        balanceDistribution.put("mid", 0);
        balanceDistribution.put("high", 0);
        balanceDistribution.put("veryHigh", 0);
        students.forEach(s -> {
            double balance = s.getCurrentBalance();
            if (balance <= 0) balanceDistribution.compute("zero", (k, v) -> v + 1);
            else if (balance <= 1000) balanceDistribution.compute("low", (k, v) -> v + 1);
            else if (balance <= 3000) balanceDistribution.compute("mid", (k, v) -> v + 1);
            else if (balance <= 5000) balanceDistribution.compute("high", (k, v) -> v + 1);
            else balanceDistribution.compute("veryHigh", (k, v) -> v + 1);
        });

        Map<String, Object> result = new HashMap<>();
        result.put("students", students);
        result.put("courses", courses);
        result.put("totalStudents", students.size());
        result.put("activeCourses", courses.size());
        result.put("totalEnrollments", totalEnrollments);
        result.put("totalCapacity", totalCapacity);
        result.put("avgUtilization", totalCapacity == 0 ? 0 : Math.round((double) totalEnrollments / totalCapacity * 100));
        result.put("totalRevenue", round(totalRevenue));
        result.put("totalCollected", round(totalCollected));
        result.put("outstanding", round(outstanding));
        result.put("collectionRate", totalRevenue == 0 ? 0 : Math.round(totalCollected / totalRevenue * 100));
        result.put("studentsWithBalance", students.stream().filter(s -> s.getCurrentBalance() > 0).count());
        result.put("paidInFull", students.stream().filter(s -> s.getCurrentBalance() <= 0).count());
        result.put("utilizationBuckets", utilizationBuckets);
        result.put("balanceDistribution", balanceDistribution);
        return result;
    }

    public Map<String, Object> dashboard() {
        return Map.of(
                "students", studentRepository.count(),
                "courses", courseRepository.count(),
                "registrations", registrationRepository.countByStatus("ENROLLED")
        );
    }

    public Map<String, Object> enrollmentStats() {
        List<CourseDto> courses = courseRepository.findAll().stream().map(mapper::toCourseDto).toList();
        int totalCapacity = courses.stream().mapToInt(CourseDto::getEnrollmentLimit).sum();
        int activeEnrollments = courses.stream().mapToInt(CourseDto::getEnrolledCount).sum();
        return Map.of(
                "activeCourses", courses.size(),
                "activeEnrollments", activeEnrollments,
                "capacity", totalCapacity,
                "rate", totalCapacity == 0 ? 0 : Math.round((double) activeEnrollments / totalCapacity * 100)
        );
    }

    public Map<String, Double> financialFull() {
        double revenue = accountRepository.findAll().stream().mapToDouble(Account::getTotalCharges).sum();
        double collected = accountRepository.findAll().stream().mapToDouble(Account::getTotalPayments).sum();
        double outstanding = accountRepository.findAll().stream().mapToDouble(Account::getCurrentBalance).sum();
        return Map.of("revenue", round(revenue), "collected", round(collected), "outstanding", round(outstanding));
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
