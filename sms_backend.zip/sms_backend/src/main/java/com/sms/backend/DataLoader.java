package com.sms.backend;

import com.sms.backend.entity.*;
import com.sms.backend.repository.*;
import com.sms.backend.service.AccountService;
import com.sms.backend.service.RegistrationService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
public class DataLoader {
    @Value("${sms.demo.reset-on-start:true}")
    private boolean resetOnStart;

    @Value("${sms.demo.service-fee:50}")
    private double serviceFee;

    @Value("${sms.demo.due-date:2026-02-14}")
    private String dueDate;

    @Bean
    CommandLineRunner seedDemoData(UserRepository userRepository,
                                   StudentRepository studentRepository,
                                   CourseRepository courseRepository,
                                   AccountRepository accountRepository,
                                   TransactionRepository transactionRepository,
                                   RegistrationRepository registrationRepository,
                                   PasswordEncoder passwordEncoder,
                                   RegistrationService registrationService,
                                   AccountService accountService) {
        return args -> {
            if (resetOnStart) {
                transactionRepository.deleteAll();
                registrationRepository.deleteAll();
                accountRepository.deleteAll();
                studentRepository.deleteAll();
                courseRepository.deleteAll();
                userRepository.deleteAll();
            }

            if (userRepository.count() > 0) return;

            Map<String, Student> students = new LinkedHashMap<>();
            students.put("1001234567", createStudent(userRepository, studentRepository, accountRepository, passwordEncoder,
                    "alex.johnson@mavs.uta.edu", "demo123", "Alex Johnson", "Computer Science", "1001234567"));
            students.put("1001234571", createStudent(userRepository, studentRepository, accountRepository, passwordEncoder,
                    "emma.wilson@mavs.uta.edu", "demo123", "Emma Wilson", "Business Administration", "1001234571"));
            students.put("1001234572", createStudent(userRepository, studentRepository, accountRepository, passwordEncoder,
                    "james.brown@mavs.uta.edu", "demo123", "James Brown", "Accounting", "1001234572"));
            students.put("1001234573", createStudent(userRepository, studentRepository, accountRepository, passwordEncoder,
                    "olivia.davis@mavs.uta.edu", "demo123", "Olivia Davis", "Biology", "1001234573"));
            students.put("1001234574", createStudent(userRepository, studentRepository, accountRepository, passwordEncoder,
                    "william.taylor@mavs.uta.edu", "demo123", "William Taylor", "Psychology", "1001234574"));
            students.put("1001234575", createStudent(userRepository, studentRepository, accountRepository, passwordEncoder,
                    "sophia.martinez@mavs.uta.edu", "demo123", "Sophia Martinez", "Information Systems", "1001234575"));

            createStaff(userRepository, passwordEncoder, "sarah.miller@uta.edu", "demo123", "Sarah Miller", Role.REGISTRAR);
            createStaff(userRepository, passwordEncoder, "david.accounts@uta.edu", "demo123", "David Accounts", Role.ACCOUNTS);
            createStaff(userRepository, passwordEncoder, "maria.garcia@uta.edu", "demo123", "Maria Garcia", Role.ADMIN);

            Course insy4325 = saveCourse(courseRepository, "INSY 4325", "Enterprise Systems Development", 3, "Dr. Amanda Foster", "COBA 215", "Mon/Wed 2:00 PM - 3:20 PM", 3, "Build enterprise-ready information systems using structured design and implementation workflows.");
            Course cse3310 = saveCourse(courseRepository, "CSE 3310", "Fundamentals of Software Engineering", 3, "Dr. Robert Kim", "ERB 103", "Tue/Thu 11:00 AM - 12:20 PM", 1, "Software life cycle concepts, requirements analysis, testing, and collaborative development.");
            Course math2326 = saveCourse(courseRepository, "MATH 2326", "Calculus III", 3, "Dr. Patricia Lee", "PKH 101", "Mon/Wed/Fri 10:00 AM - 10:50 AM", 3, "Multivariable calculus with vectors, partial derivatives, and multiple integration.");
            Course engl1302 = saveCourse(courseRepository, "ENGL 1302", "Rhetoric and Composition II", 3, "Prof. Michael Torres", "LIBR 202", "Tue/Thu 9:30 AM - 10:50 AM", 3, "Research, argumentation, and analytical writing across academic and professional contexts.");
            Course phys1441 = saveCourse(courseRepository, "PHYS 1441", "General Technical Physics I", 4, "Dr. Jennifer Adams", "SH 100", "Mon/Wed 3:30 PM - 4:50 PM", 2, "Mechanics and foundational physics concepts for technical majors.");
            Course acct2301 = saveCourse(courseRepository, "ACCT 2301", "Principles of Accounting I", 3, "Dr. Lisa Wang", "COBA 140", "Mon/Wed 1:00 PM - 2:20 PM", 3, "Financial accounting principles, reporting, and analysis for business decisions.");
            Course biol1441 = saveCourse(courseRepository, "BIOL 1441", "Cell and Molecular Biology", 4, "Dr. Susan Clark", "LS 103", "Tue/Thu 1:00 PM - 2:20 PM", 2, "Cell structure, metabolism, genetics, and molecular biology principles.");
            Course psyc1315 = saveCourse(courseRepository, "PSYC 1315", "Introduction to Psychology", 3, "Dr. Mark Johnson", "UH 100", "Mon/Wed/Fri 11:00 AM - 11:50 AM", 2, "Survey of psychological theories, research methods, and human behavior.");

            registrationService.register("1001234567", insy4325.getCourseId());
            registrationService.register("1001234567", math2326.getCourseId());
            registrationService.register("1001234567", phys1441.getCourseId());
            registrationService.register("1001234571", cse3310.getCourseId());
            registrationService.register("1001234571", engl1302.getCourseId());
            registrationService.register("1001234572", acct2301.getCourseId());
            registrationService.register("1001234573", biol1441.getCourseId());
            registrationService.register("1001234573", engl1302.getCourseId());
            registrationService.register("1001234574", psyc1315.getCourseId());
            registrationService.register("1001234574", math2326.getCourseId());
            registrationService.register("1001234575", insy4325.getCourseId());
            registrationService.register("1001234575", acct2301.getCourseId());

            for (Student student : students.values()) {
                if (registrationRepository.findByStudent(student).stream().anyMatch(r -> "ENROLLED".equals(r.getStatus()))) {
                    accountService.applyCharge(student, serviceFee, "FEE", "Student service fee");
                }
            }

            accountService.applyPayment("1001234572", 1400, "Online payment • Paid in full");
            accountService.applyPayment("1001234573", 1800, "Scholarship and partial payment");
            accountService.applyPayment("1001234575", 1300, "Payment plan installment");
        };
    }

    private Student createStudent(UserRepository userRepository, StudentRepository studentRepository, AccountRepository accountRepository,
                                  PasswordEncoder passwordEncoder, String username, String password, String name, String major, String studentId) {
        User user = new User();
        user.setUsername(username);
        user.setEmail(username);
        user.setPassword(passwordEncoder.encode(password));
        user.setName(name);
        user.setRole(Role.STUDENT);
        userRepository.save(user);

        Student student = new Student();
        student.setStudentId(studentId);
        student.setMajor(major);
        student.setCreditHours(0);
        student.setUser(user);
        studentRepository.save(student);

        Account account = new Account();
        account.setStudent(student);
        account.setCurrentBalance(0);
        account.setTotalCharges(0);
        account.setTotalPayments(0);
        account.setDueDate(LocalDate.parse(dueDate));
        accountRepository.save(account);
        return student;
    }

    private void createStaff(UserRepository userRepository, PasswordEncoder passwordEncoder, String username, String password, String name, Role role) {
        User user = new User();
        user.setUsername(username);
        user.setEmail(username);
        user.setPassword(passwordEncoder.encode(password));
        user.setName(name);
        user.setRole(role);
        userRepository.save(user);
    }

    private Course saveCourse(CourseRepository courseRepository, String code, String name, int hours, String instructor, String room, String schedule, int capacity, String description) {
        Course course = new Course();
        course.setCourseCode(code);
        course.setCourseName(name);
        course.setCourseHours(hours);
        course.setInstructor(instructor);
        course.setRoomNum(room);
        course.setSchedule(schedule);
        course.setEnrollmentLimit(capacity);
        course.setDescription(description);
        return courseRepository.save(course);
    }
}
