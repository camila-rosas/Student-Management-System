package com.sms.backend.controller;

import com.sms.backend.dto.UserDto;
import com.sms.backend.entity.User;
import com.sms.backend.service.DtoMapper;
import com.sms.backend.service.UserService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserService userService;
    private final DtoMapper mapper;

    public UserController(UserService userService, DtoMapper mapper) {
        this.userService = userService;
        this.mapper = mapper;
    }

    @GetMapping("/me")
    public UserDto me(Authentication authentication) {
        User user = userService.getByUsername(authentication.getName());
        return mapper.toUserDto(user, userService.getStudentIdForUser(user));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public List<UserDto> all() {
        return userService.getAllUsers().stream()
                .map(u -> mapper.toUserDto(u, userService.getStudentIdForUser(u)))
                .toList();
    }
}
