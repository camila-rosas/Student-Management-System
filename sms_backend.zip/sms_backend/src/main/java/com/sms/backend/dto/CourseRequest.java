package com.sms.backend.dto;

public class CourseRequest {
    private String courseCode;
    private String code;
    private String courseName;
    private String name;
    private Integer courseHours;
    private Integer hours;
    private String instructor;
    private Integer enrollmentLimit;
    private String schedule;
    private String roomNum;
    private String location;
    private String description;

    public String resolvedCode() { return first(courseCode, code); }
    public String resolvedName() { return first(courseName, name); }
    public int resolvedHours() { return courseHours != null ? courseHours : (hours != null ? hours : 0); }
    public String resolvedRoomNum() { return first(roomNum, location); }

    private String first(String a, String b) {
        if (a != null && !a.isBlank()) return a;
        return b;
    }

    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getCourseHours() { return courseHours; }
    public void setCourseHours(Integer courseHours) { this.courseHours = courseHours; }
    public Integer getHours() { return hours; }
    public void setHours(Integer hours) { this.hours = hours; }
    public String getInstructor() { return instructor; }
    public void setInstructor(String instructor) { this.instructor = instructor; }
    public Integer getEnrollmentLimit() { return enrollmentLimit; }
    public void setEnrollmentLimit(Integer enrollmentLimit) { this.enrollmentLimit = enrollmentLimit; }
    public String getSchedule() { return schedule; }
    public void setSchedule(String schedule) { this.schedule = schedule; }
    public String getRoomNum() { return roomNum; }
    public void setRoomNum(String roomNum) { this.roomNum = roomNum; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
