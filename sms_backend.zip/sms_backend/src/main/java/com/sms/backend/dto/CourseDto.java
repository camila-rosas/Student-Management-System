package com.sms.backend.dto;

public class CourseDto {
    private String courseId;
    private String id;
    private String courseCode;
    private String code;
    private String courseName;
    private String name;
    private int courseHours;
    private int hours;
    private String instructor;
    private int enrollmentLimit;
    private String schedule;
    private String roomNum;
    private String description;
    private int enrolledCount;
    private int seatsLeft;
    private boolean isEnrolled;
    private String registrationId;

    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; this.id = courseId; }
    public String getId() { return id; }
    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; this.code = courseCode; }
    public String getCode() { return code; }
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; this.name = courseName; }
    public String getName() { return name; }
    public int getCourseHours() { return courseHours; }
    public void setCourseHours(int courseHours) { this.courseHours = courseHours; this.hours = courseHours; }
    public int getHours() { return hours; }
    public String getInstructor() { return instructor; }
    public void setInstructor(String instructor) { this.instructor = instructor; }
    public int getEnrollmentLimit() { return enrollmentLimit; }
    public void setEnrollmentLimit(int enrollmentLimit) { this.enrollmentLimit = enrollmentLimit; }
    public String getSchedule() { return schedule; }
    public void setSchedule(String schedule) { this.schedule = schedule; }
    public String getRoomNum() { return roomNum; }
    public void setRoomNum(String roomNum) { this.roomNum = roomNum; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public int getEnrolledCount() { return enrolledCount; }
    public void setEnrolledCount(int enrolledCount) { this.enrolledCount = enrolledCount; }
    public int getSeatsLeft() { return seatsLeft; }
    public void setSeatsLeft(int seatsLeft) { this.seatsLeft = seatsLeft; }
    public boolean isEnrolled() { return isEnrolled; }
    public void setEnrolled(boolean enrolled) { isEnrolled = enrolled; }
    public String getRegistrationId() { return registrationId; }
    public void setRegistrationId(String registrationId) { this.registrationId = registrationId; }
}
