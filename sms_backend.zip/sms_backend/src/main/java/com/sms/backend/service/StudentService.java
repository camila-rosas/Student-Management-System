package com.sms.backend.service;

import com.sms.backend.dto.CourseDto;
import com.sms.backend.dto.StudentDto;
import com.sms.backend.entity.Registration;
import com.sms.backend.entity.Student;
import com.sms.backend.entity.User;
import com.sms.backend.repository.CourseRepository;
import com.sms.backend.repository.RegistrationRepository;
import com.sms.backend.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class StudentService {
    private final StudentRepository studentRepository;
    private final RegistrationRepository registrationRepository;
    private final CourseRepository courseRepository;
    private final AccountService accountService;
    private final DtoMapper mapper;

    public StudentService(StudentRepository studentRepository, RegistrationRepository registrationRepository,
                          CourseRepository courseRepository, AccountService accountService, DtoMapper mapper) {
        this.studentRepository = studentRepository;
        this.registrationRepository = registrationRepository;
        this.courseRepository = courseRepository;
        this.accountService = accountService;
        this.mapper = mapper;
    }

    public Student getByUser(User user) {
        return studentRepository.findByUser_UserId(user.getUserId())
                .orElseThrow(() -> new RuntimeException("Student profile not found."));
    }

    public Student getEntity(String studentId) {
        return studentRepository.findById(studentId).orElseThrow(() -> new RuntimeException("Student not found."));
    }

    public List<StudentDto> getAllStudents() {
        return studentRepository.findAll().stream().map(mapper::toStudentDto).toList();
    }

    public StudentDto getStudent(String studentId) {
        return mapper.toStudentDto(getEntity(studentId));
    }

    public Map<String, Object> dashboard(Student student) {
        var regs = registrationRepository.findByStudent(student).stream()
                .filter(r -> "ENROLLED".equals(r.getStatus()))
                .toList();
        int credits = regs.stream().mapToInt(r -> r.getCourse().getCourseHours()).sum();
        double balance = accountService.getAccountEntityByStudentId(student.getStudentId()).getCurrentBalance();
        long availableCourses = courseRepository.findAll().stream()
                .filter(c -> registrationRepository.countByCourseAndStatus(c, "ENROLLED") < c.getEnrollmentLimit())
                .count();
        return Map.of(
                "courses", regs.size(),
                "credits", credits,
                "balance", balance,
                "availableCourses", availableCourses
        );
    }

    public List<CourseDto> catalogForStudent(Student student) {
        List<Registration> activeRegs = registrationRepository.findByStudent(student).stream()
                .filter(r -> "ENROLLED".equals(r.getStatus()))
                .toList();
        Set<Long> enrolledCourseIds = activeRegs.stream().map(r -> r.getCourse().getCourseId()).collect(Collectors.toSet());
        Map<Long, String> registrationIds = activeRegs.stream().collect(Collectors.toMap(r -> r.getCourse().getCourseId(), r -> String.valueOf(r.getRegistrationId())));
        return courseRepository.findAll().stream()
                .map(c -> mapper.toCourseDto(c, enrolledCourseIds.contains(c.getCourseId()), registrationIds.get(c.getCourseId())))
                .toList();
    }
}
