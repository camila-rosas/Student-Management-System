package com.sms.backend.repository;

import com.sms.backend.entity.Course;
import com.sms.backend.entity.Registration;
import com.sms.backend.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface RegistrationRepository extends JpaRepository<Registration, Long> {
    List<Registration> findByStudent(Student student);
    List<Registration> findByCourse(Course course);
    Optional<Registration> findByStudentAndCourseAndStatus(Student student, Course course, String status);
    int countByCourseAndStatus(Course course, String status);
    int countByStatus(String status);
}
