package com.sms.backend.controller;

import com.sms.backend.dto.RegistrationDto;
import com.sms.backend.entity.Student;
import com.sms.backend.entity.User;
import com.sms.backend.service.RegistrationService;
import com.sms.backend.service.StudentService;
import com.sms.backend.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/registration")
public class RegistrationController {
    private final RegistrationService registrationService;
    private final StudentService studentService;
    private final UserService userService;

    public RegistrationController(RegistrationService registrationService, StudentService studentService, UserService userService) {
        this.registrationService = registrationService;
        this.studentService = studentService;
        this.userService = userService;
    }

    @GetMapping("/my")
    public List<RegistrationDto> myCourses(Authentication auth) {
        User user = userService.getByUsername(auth.getName());
        Student student = studentService.getByUser(user);
        return registrationService.getRegistrationsForStudent(student.getStudentId());
    }

    @PostMapping
    public RegistrationDto register(@RequestParam String studentId, @RequestParam Long courseId) {
        return registrationService.register(studentId, courseId);
    }

    @PostMapping("/enroll")
    public RegistrationDto enroll(@RequestParam String studentId, @RequestParam Long courseId) {
        return registrationService.register(studentId, courseId);
    }

    @DeleteMapping("/drop/{id}")
    public RegistrationDto drop(@PathVariable Long id) {
        return registrationService.drop(id);
    }
}
