package com.sms.backend.entity;

public enum Role {
    STUDENT,
    REGISTRAR,
    ACCOUNTS,
    ADMIN
}
