package com.sms.backend.controller;

import com.sms.backend.service.ReportService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/reports")
public class ReportController {
    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping("/summary")
    public Map<String, Object> summary() {
        return reportService.summary();
    }

    @GetMapping("/dashboard")
    public Map<String, Object> dashboard() {
        return reportService.dashboard();
    }

    @GetMapping("/enrollment/stats")
    public Map<String, Object> enrollmentStats() {
        return reportService.enrollmentStats();
    }

    @GetMapping("/financial/full")
    public Map<String, Double> financialFull() {
        return reportService.financialFull();
    }
}
