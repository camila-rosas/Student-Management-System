package com.sms.backend.repository;

import com.sms.backend.entity.Account;
import com.sms.backend.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, Long> {
    Optional<Account> findByStudent(Student student);
    Optional<Account> findByStudent_StudentId(String studentId);
}
