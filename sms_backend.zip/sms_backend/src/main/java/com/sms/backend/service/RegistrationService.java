package com.sms.backend.service;

import com.sms.backend.dto.RegistrationDto;
import com.sms.backend.entity.Course;
import com.sms.backend.entity.Registration;
import com.sms.backend.entity.Student;
import com.sms.backend.repository.CourseRepository;
import com.sms.backend.repository.RegistrationRepository;
import com.sms.backend.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class RegistrationService {
    private final RegistrationRepository registrationRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    private final AccountService accountService;
    private final DtoMapper mapper;

    @Value("${sms.demo.tuition-per-credit:450}")
    private double tuitionPerCredit;

    @Value("${sms.demo.max-student-hours:18}")
    private int maxStudentHours;

    @Value("${sms.demo.term:Spring 2026}")
    private String term;

    public RegistrationService(RegistrationRepository registrationRepository, StudentRepository studentRepository,
                               CourseRepository courseRepository, AccountService accountService, DtoMapper mapper) {
        this.registrationRepository = registrationRepository;
        this.studentRepository = studentRepository;
        this.courseRepository = courseRepository;
        this.accountService = accountService;
        this.mapper = mapper;
    }

    public List<RegistrationDto> getRegistrationsForStudent(String studentId) {
        Student student = studentRepository.findById(studentId).orElseThrow(() -> new RuntimeException("Student not found."));
        return registrationRepository.findByStudent(student).stream().map(mapper::toRegistrationDto).toList();
    }

    @Transactional
    public RegistrationDto register(String studentId, Long courseId) {
        Student student = studentRepository.findById(studentId).orElseThrow(() -> new RuntimeException("Student not found."));
        Course course = courseRepository.findById(courseId).orElseThrow(() -> new RuntimeException("Course not found."));

        if (registrationRepository.findByStudentAndCourseAndStatus(student, course, "ENROLLED").isPresent()) {
            throw new RuntimeException("This student is already enrolled in the selected course.");
        }

        int enrolledCount = registrationRepository.countByCourseAndStatus(course, "ENROLLED");
        if (enrolledCount >= course.getEnrollmentLimit()) {
            throw new RuntimeException("This course is already full.");
        }

        int currentHours = activeCreditHours(student);
        if (currentHours + course.getCourseHours() > maxStudentHours) {
            throw new RuntimeException("This enrollment would exceed the " + maxStudentHours + "-hour limit.");
        }

        Registration registration = new Registration();
        registration.setStudent(student);
        registration.setCourse(course);
        registration.setSemester(term);
        registration.setRegistrationDate(LocalDate.now());
        registration.setStatus("ENROLLED");
        Registration saved = registrationRepository.save(registration);

        double charge = course.getCourseHours() * tuitionPerCredit;
        accountService.applyCharge(student, charge, "TUITION", "Tuition charge • " + course.getCourseCode());
        student.setCreditHours(activeCreditHours(student));
        studentRepository.save(student);
        return mapper.toRegistrationDto(saved);
    }

    @Transactional
    public RegistrationDto drop(Long registrationId) {
        Registration registration = registrationRepository.findById(registrationId)
                .orElseThrow(() -> new RuntimeException("Registration not found."));

        if (!"ENROLLED".equals(registration.getStatus())) {
            throw new RuntimeException("This registration is already dropped.");
        }

        registration.setStatus("DROPPED");
        Registration saved = registrationRepository.save(registration);

        double adjustment = -(registration.getCourse().getCourseHours() * tuitionPerCredit);
        accountService.applyCharge(registration.getStudent(), adjustment, "DROP_ADJUSTMENT", "Dropped course adjustment • " + registration.getCourse().getCourseCode());
        Student student = registration.getStudent();
        student.setCreditHours(activeCreditHours(student));
        studentRepository.save(student);
        return mapper.toRegistrationDto(saved);
    }

    public int activeCreditHours(Student student) {
        return registrationRepository.findByStudent(student).stream()
                .filter(r -> "ENROLLED".equals(r.getStatus()))
                .mapToInt(r -> r.getCourse().getCourseHours())
                .sum();
    }
}
