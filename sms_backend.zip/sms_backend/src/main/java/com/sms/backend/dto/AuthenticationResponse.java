package com.sms.backend.dto;

public class AuthenticationResponse {
    private String token;
    private String role;
    private UserDto user;

    public AuthenticationResponse(String token, String role, UserDto user) {
        this.token = token;
        this.role = role;
        this.user = user;
    }

    public String getToken() { return token; }
    public String getRole() { return role; }
    public UserDto getUser() { return user; }
}
