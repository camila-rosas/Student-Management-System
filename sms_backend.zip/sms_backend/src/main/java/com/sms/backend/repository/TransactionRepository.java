package com.sms.backend.repository;

import com.sms.backend.entity.Account;
import com.sms.backend.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByAccountOrderByDateDescTransactionIdDesc(Account account);
}
