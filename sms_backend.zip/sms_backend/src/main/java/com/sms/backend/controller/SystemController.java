package com.sms.backend.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class SystemController {
    @Value("${sms.demo.term:Spring 2026}")
    private String term;

    @Value("${sms.demo.tuition-per-credit:450}")
    private double tuitionPerCredit;

    @Value("${sms.demo.service-fee:50}")
    private double serviceFee;

    @Value("${sms.demo.max-student-hours:18}")
    private int maxStudentHours;

    @Value("${sms.demo.due-date:2026-02-14}")
    private String dueDate;

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of("status", "UP", "database", "MySQL", "application", "Student Management System");
    }

    @GetMapping("/config")
    public Map<String, Object> config() {
        return Map.of(
                "term", term,
                "tuitionPerCredit", tuitionPerCredit,
                "serviceFee", serviceFee,
                "maxStudentHours", maxStudentHours,
                "dueDate", dueDate
        );
    }
}
