package com.sms.backend.dto;

import java.util.List;

public class StudentDto {
    private String studentId;
    private String id;
    private String name;
    private String username;
    private String email;
    private String major;
    private String avatar;
    private int creditHours;
    private int enrollments;
    private double balance;
    private double currentBalance;
    private double totalCharges;
    private double totalPayments;
    private String lastPaymentDate;
    private List<RegistrationDto> registrations;

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; this.id = studentId; }
    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; this.email = username; }
    public String getEmail() { return email; }
    public String getMajor() { return major; }
    public void setMajor(String major) { this.major = major; }
    public String getAvatar() { return avatar; }
    public void setAvatar(String avatar) { this.avatar = avatar; }
    public int getCreditHours() { return creditHours; }
    public void setCreditHours(int creditHours) { this.creditHours = creditHours; }
    public int getEnrollments() { return enrollments; }
    public void setEnrollments(int enrollments) { this.enrollments = enrollments; }
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; this.currentBalance = balance; }
    public double getCurrentBalance() { return currentBalance; }
    public double getTotalCharges() { return totalCharges; }
    public void setTotalCharges(double totalCharges) { this.totalCharges = totalCharges; }
    public double getTotalPayments() { return totalPayments; }
    public void setTotalPayments(double totalPayments) { this.totalPayments = totalPayments; }
    public String getLastPaymentDate() { return lastPaymentDate; }
    public void setLastPaymentDate(String lastPaymentDate) { this.lastPaymentDate = lastPaymentDate; }
    public List<RegistrationDto> getRegistrations() { return registrations; }
    public void setRegistrations(List<RegistrationDto> registrations) { this.registrations = registrations; }
}
