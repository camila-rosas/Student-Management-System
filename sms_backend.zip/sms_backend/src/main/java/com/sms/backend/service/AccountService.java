package com.sms.backend.service;

import com.sms.backend.dto.AccountDto;
import com.sms.backend.entity.Account;
import com.sms.backend.entity.Student;
import com.sms.backend.entity.Transaction;
import com.sms.backend.repository.AccountRepository;
import com.sms.backend.repository.StudentRepository;
import com.sms.backend.repository.TransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class AccountService {
    private final AccountRepository accountRepository;
    private final StudentRepository studentRepository;
    private final TransactionRepository transactionRepository;
    private final DtoMapper mapper;

    public AccountService(AccountRepository accountRepository, StudentRepository studentRepository,
                          TransactionRepository transactionRepository, DtoMapper mapper) {
        this.accountRepository = accountRepository;
        this.studentRepository = studentRepository;
        this.transactionRepository = transactionRepository;
        this.mapper = mapper;
    }

    public Account getAccountEntityByStudentId(String studentId) {
        return accountRepository.findByStudent_StudentId(studentId)
                .orElseThrow(() -> new RuntimeException("Account not found for student."));
    }

    public AccountDto getByStudentId(String studentId) {
        return mapper.toAccountDto(getAccountEntityByStudentId(studentId));
    }

    public List<AccountDto> getAllAccounts() {
        return accountRepository.findAll().stream().map(mapper::toAccountDto).toList();
    }

    @Transactional
    public Account applyCharge(Student student, double amount, String type, String description) {
        Account account = accountRepository.findByStudent(student).orElseThrow(() -> new RuntimeException("Account not found."));
        account.setTotalCharges(round(account.getTotalCharges() + amount));
        account.setCurrentBalance(round(account.getCurrentBalance() + amount));
        accountRepository.save(account);
        addTransaction(account, type, description, amount);
        return account;
    }

    @Transactional
    public AccountDto applyFee(String studentId, double amount, String description) {
        Student student = studentRepository.findById(studentId).orElseThrow(() -> new RuntimeException("Student not found."));
        return mapper.toAccountDto(applyCharge(student, amount, "FEE", description == null || description.isBlank() ? "Manual fee" : description));
    }

    @Transactional
    public AccountDto applyPayment(String studentId, double amount, String description) {
        if (amount <= 0) throw new RuntimeException("Payment amount must be greater than 0.");
        Account account = getAccountEntityByStudentId(studentId);
        account.setTotalPayments(round(account.getTotalPayments() + amount));
        account.setCurrentBalance(round(account.getCurrentBalance() - amount));
        accountRepository.save(account);
        addTransaction(account, "PAYMENT", description == null || description.isBlank() ? "Manual payment" : description, -Math.abs(amount));
        return mapper.toAccountDto(account);
    }

    public Map<String, Object> summary() {
        List<Account> accounts = accountRepository.findAll();
        double outstanding = accounts.stream().mapToDouble(Account::getCurrentBalance).sum();
        long paidFull = accounts.stream().filter(a -> a.getCurrentBalance() <= 0).count();
        return Map.of(
                "totalStudents", accounts.size(),
                "outstanding", round(outstanding),
                "paidFull", paidFull,
                "studentsWithBalance", accounts.size() - paidFull
        );
    }

    private void addTransaction(Account account, String type, String description, double amount) {
        Transaction transaction = new Transaction();
        transaction.setAccount(account);
        transaction.setDate(LocalDate.now());
        transaction.setType(type);
        transaction.setDescription(description);
        transaction.setAmount(round(amount));
        transactionRepository.save(transaction);
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
