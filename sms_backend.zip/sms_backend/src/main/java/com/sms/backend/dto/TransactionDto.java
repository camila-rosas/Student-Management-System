package com.sms.backend.dto;

public class TransactionDto {
    private String transactionId;
    private String type;
    private String description;
    private String date;
    private double amount;

    public TransactionDto(String transactionId, String type, String description, String date, double amount) {
        this.transactionId = transactionId;
        this.type = type;
        this.description = description;
        this.date = date;
        this.amount = amount;
    }

    public String getTransactionId() { return transactionId; }
    public String getType() { return type; }
    public String getDescription() { return description; }
    public String getDate() { return date; }
    public double getAmount() { return amount; }
}
