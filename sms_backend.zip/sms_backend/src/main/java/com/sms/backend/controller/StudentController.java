package com.sms.backend.controller;

import com.sms.backend.dto.AccountDto;
import com.sms.backend.dto.CourseDto;
import com.sms.backend.dto.RegistrationDto;
import com.sms.backend.dto.StudentDto;
import com.sms.backend.entity.Student;
import com.sms.backend.entity.User;
import com.sms.backend.service.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/students")
public class StudentController {
    private final StudentService studentService;
    private final UserService userService;
    private final RegistrationService registrationService;
    private final AccountService accountService;
    private final DtoMapper mapper;

    public StudentController(StudentService studentService, UserService userService,
                             RegistrationService registrationService, AccountService accountService, DtoMapper mapper) {
        this.studentService = studentService;
        this.userService = userService;
        this.registrationService = registrationService;
        this.accountService = accountService;
        this.mapper = mapper;
    }

    @GetMapping
    @PreAuthorize("hasRole('REGISTRAR') or hasRole('ACCOUNTS') or hasRole('ADMIN')")
    public List<StudentDto> allStudents() {
        return studentService.getAllStudents();
    }

    @GetMapping("/me")
    public StudentDto me(Authentication auth) {
        Student student = currentStudent(auth);
        return mapper.toStudentDto(student);
    }

    @GetMapping("/dashboard")
    public Map<String, Object> myDashboard(Authentication auth) {
        return studentService.dashboard(currentStudent(auth));
    }

    @GetMapping("/{studentId}/dashboard")
    @PreAuthorize("hasRole('REGISTRAR') or hasRole('ACCOUNTS') or hasRole('ADMIN')")
    public Map<String, Object> dashboardForStudent(@PathVariable String studentId) {
        return studentService.dashboard(studentService.getEntity(studentId));
    }

    @GetMapping("/courses")
    public List<CourseDto> myCatalog(Authentication auth) {
        return studentService.catalogForStudent(currentStudent(auth));
    }

    @GetMapping("/{studentId}/registrations")
    @PreAuthorize("hasRole('REGISTRAR') or hasRole('ACCOUNTS') or hasRole('ADMIN')")
    public List<RegistrationDto> registrationsForStudent(@PathVariable String studentId) {
        return registrationService.getRegistrationsForStudent(studentId);
    }

    @GetMapping("/billing")
    public AccountDto billing(Authentication auth) {
        return accountService.getByStudentId(currentStudent(auth).getStudentId());
    }

    @PostMapping("/enroll")
    public RegistrationDto enrollMe(Authentication auth, @RequestParam Long courseId) {
        return registrationService.register(currentStudent(auth).getStudentId(), courseId);
    }

    @PostMapping("/{studentId}/enroll")
    @PreAuthorize("hasRole('REGISTRAR') or hasRole('ADMIN')")
    public RegistrationDto enrollStudent(@PathVariable String studentId, @RequestParam Long courseId) {
        return registrationService.register(studentId, courseId);
    }

    private Student currentStudent(Authentication auth) {
        User user = userService.getByUsername(auth.getName());
        return studentService.getByUser(user);
    }
}
