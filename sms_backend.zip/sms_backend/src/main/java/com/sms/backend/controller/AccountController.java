package com.sms.backend.controller;

import com.sms.backend.dto.AccountDto;
import com.sms.backend.dto.StudentDto;
import com.sms.backend.service.AccountService;
import com.sms.backend.service.StudentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {
    private final AccountService accountService;
    private final StudentService studentService;

    public AccountController(AccountService accountService, StudentService studentService) {
        this.accountService = accountService;
        this.studentService = studentService;
    }

    @GetMapping("/summary")
    public Map<String, Object> summary() {
        return accountService.summary();
    }

    @GetMapping("/students")
    public List<StudentDto> students() {
        return studentService.getAllStudents();
    }

    @GetMapping("/{studentId}")
    public AccountDto account(@PathVariable String studentId) {
        return accountService.getByStudentId(studentId);
    }

    @PostMapping("/{studentId}/fee")
    public AccountDto applyFee(@PathVariable String studentId, @RequestParam double amount,
                               @RequestParam(required = false) String description) {
        return accountService.applyFee(studentId, amount, description);
    }

    @PostMapping("/{studentId}/payment")
    public AccountDto applyPayment(@PathVariable String studentId, @RequestParam double amount,
                                   @RequestParam(required = false) String description) {
        return accountService.applyPayment(studentId, amount, description);
    }
}
