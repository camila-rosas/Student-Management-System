package com.sms.backend.dto;

public class RegistrationDto {
    private String registrationId;
    private String id;
    private String studentId;
    private CourseDto course;
    private String semester;
    private String registrationDate;
    private String status;

    public RegistrationDto(String registrationId, String studentId, CourseDto course, String semester, String registrationDate, String status) {
        this.registrationId = registrationId;
        this.id = registrationId;
        this.studentId = studentId;
        this.course = course;
        this.semester = semester;
        this.registrationDate = registrationDate;
        this.status = status;
    }

    public String getRegistrationId() { return registrationId; }
    public String getId() { return id; }
    public String getStudentId() { return studentId; }
    public CourseDto getCourse() { return course; }
    public String getSemester() { return semester; }
    public String getRegistrationDate() { return registrationDate; }
    public String getStatus() { return status; }
}
