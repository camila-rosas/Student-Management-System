package com.sms.backend.service;

import com.sms.backend.dto.CourseDto;
import com.sms.backend.dto.CourseRequest;
import com.sms.backend.entity.Course;
import com.sms.backend.entity.Registration;
import com.sms.backend.entity.Student;
import com.sms.backend.repository.CourseRepository;
import com.sms.backend.repository.RegistrationRepository;
import com.sms.backend.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Service
public class CourseService {
    private final CourseRepository courseRepository;
    private final RegistrationRepository registrationRepository;
    private final StudentRepository studentRepository;
    private final AccountService accountService;
    private final DtoMapper mapper;

    @Value("${sms.demo.tuition-per-credit:450}")
    private double tuitionPerCredit;

    public CourseService(CourseRepository courseRepository,
                         RegistrationRepository registrationRepository,
                         StudentRepository studentRepository,
                         AccountService accountService,
                         DtoMapper mapper) {
        this.courseRepository = courseRepository;
        this.registrationRepository = registrationRepository;
        this.studentRepository = studentRepository;
        this.accountService = accountService;
        this.mapper = mapper;
    }

    public List<CourseDto> getAllCourses() {
        return courseRepository.findAll().stream()
                .map(mapper::toCourseDto)
                .toList();
    }

    public Course getEntity(Long id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found."));
    }

    public CourseDto create(CourseRequest request) {
        Course course = new Course();
        applyRequest(course, request, false);
        return mapper.toCourseDto(courseRepository.save(course));
    }

    public CourseDto update(Long id, CourseRequest request) {
        Course course = getEntity(id);
        applyRequest(course, request, true);

        int enrolled = registrationRepository.countByCourseAndStatus(course, "ENROLLED");

        if (course.getEnrollmentLimit() < enrolled) {
            throw new RuntimeException("Capacity cannot be lower than the current enrollment.");
        }

        return mapper.toCourseDto(courseRepository.save(course));
    }

    @Transactional
    public void delete(Long id) {
        Course course = getEntity(id);
        List<Registration> registrations = registrationRepository.findByCourse(course);
        Set<Student> affectedStudents = new HashSet<>();

        for (Registration registration : registrations) {
            Student student = registration.getStudent();
            affectedStudents.add(student);

            if ("ENROLLED".equals(registration.getStatus())) {
                double adjustment = -(course.getCourseHours() * tuitionPerCredit);

                accountService.applyCharge(
                        student,
                        adjustment,
                        "COURSE_DELETE_ADJUSTMENT",
                        "Deleted course adjustment • " + course.getCourseCode()
                );
            }
        }

        registrationRepository.deleteAll(registrations);
        courseRepository.delete(course);

        for (Student student : affectedStudents) {
            student.setCreditHours(activeCreditHours(student));
            studentRepository.save(student);
        }
    }

    public List<CourseDto> search(String keyword) {
        String needle = keyword == null ? "" : keyword.toLowerCase(Locale.ROOT);

        return courseRepository.findAll().stream()
                .filter(c -> contains(c.getCourseCode(), needle)
                        || contains(c.getCourseName(), needle)
                        || contains(c.getInstructor(), needle)
                        || contains(c.getSchedule(), needle)
                        || contains(c.getRoomNum(), needle))
                .map(mapper::toCourseDto)
                .toList();
    }

    public List<CourseDto> filter(String type) {
        String value = type == null ? "" : type.toLowerCase(Locale.ROOT);

        return courseRepository.findAll().stream()
                .filter(c -> {
                    int enrolled = registrationRepository.countByCourseAndStatus(c, "ENROLLED");

                    if ("open".equals(value)) {
                        return enrolled < c.getEnrollmentLimit();
                    }

                    if ("3".equals(value)) {
                        return c.getCourseHours() == 3;
                    }

                    if ("4".equals(value)) {
                        return c.getCourseHours() == 4;
                    }

                    return true;
                })
                .map(mapper::toCourseDto)
                .toList();
    }

    private int activeCreditHours(Student student) {
        return registrationRepository.findByStudent(student).stream()
                .filter(r -> "ENROLLED".equals(r.getStatus()))
                .mapToInt(r -> r.getCourse().getCourseHours())
                .sum();
    }

    private boolean contains(String value, String needle) {
        return value != null && value.toLowerCase(Locale.ROOT).contains(needle);
    }

    private void applyRequest(Course course, CourseRequest request, boolean updating) {
        String code = clean(request.resolvedCode()).toUpperCase(Locale.ROOT);
        String name = clean(request.resolvedName());
        String instructor = clean(request.getInstructor());
        String roomNum = clean(request.resolvedRoomNum());
        String schedule = clean(request.getSchedule());
        String description = clean(request.getDescription());

        int hours = request.resolvedHours();
        int limit = request.getEnrollmentLimit() == null ? 0 : request.getEnrollmentLimit();

        if (code.isBlank()
                || name.isBlank()
                || instructor.isBlank()
                || roomNum.isBlank()
                || schedule.isBlank()
                || description.isBlank()) {
            throw new RuntimeException("Every course field is required.");
        }

        if (hours <= 0) {
            throw new RuntimeException("Credit hours must be greater than 0.");
        }

        if (limit <= 0) {
            throw new RuntimeException("Capacity must be greater than 0.");
        }

        courseRepository.findByCourseCodeIgnoreCase(code).ifPresent(existing -> {
            if (!updating || !existing.getCourseId().equals(course.getCourseId())) {
                throw new RuntimeException("Course code already exists.");
            }
        });

        course.setCourseCode(code);
        course.setCourseName(name);
        course.setCourseHours(hours);
        course.setInstructor(instructor);
        course.setRoomNum(roomNum);
        course.setSchedule(schedule);
        course.setDescription(description);
        course.setEnrollmentLimit(limit);
    }

    private String clean(String value) {
        return value == null ? "" : value.trim();
    }
}