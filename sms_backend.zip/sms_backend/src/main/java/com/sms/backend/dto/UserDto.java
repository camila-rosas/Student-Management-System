package com.sms.backend.dto;

public class UserDto {
    private Long userId;
    private String username;
    private String email;
    private String name;
    private String role;
    private String studentId;

    public UserDto(Long userId, String username, String email, String name, String role, String studentId) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.name = name;
        this.role = role;
        this.studentId = studentId;
    }

    public Long getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getEmail() { return email; }
    public String getName() { return name; }
    public String getRole() { return role; }
    public String getStudentId() { return studentId; }
}
