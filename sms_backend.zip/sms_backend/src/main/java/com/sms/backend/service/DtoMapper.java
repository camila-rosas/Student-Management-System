package com.sms.backend.service;

import com.sms.backend.dto.*;
import com.sms.backend.entity.*;
import com.sms.backend.repository.*;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
public class DtoMapper {
    private final RegistrationRepository registrationRepository;
    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;

    public DtoMapper(RegistrationRepository registrationRepository,
                     AccountRepository accountRepository,
                     TransactionRepository transactionRepository) {
        this.registrationRepository = registrationRepository;
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
    }

    public UserDto toUserDto(User user, String studentId) {
        return new UserDto(user.getUserId(), user.getUsername(), user.getEmail(), user.getName(), user.getRole().name(), studentId);
    }

    public CourseDto toCourseDto(Course course) {
        return toCourseDto(course, false, null);
    }

    public CourseDto toCourseDto(Course course, boolean enrolled, String registrationId) {
        int enrolledCount = registrationRepository.countByCourseAndStatus(course, "ENROLLED");
        CourseDto dto = new CourseDto();
        dto.setCourseId(String.valueOf(course.getCourseId()));
        dto.setCourseCode(course.getCourseCode());
        dto.setCourseName(course.getCourseName());
        dto.setCourseHours(course.getCourseHours());
        dto.setInstructor(course.getInstructor());
        dto.setEnrollmentLimit(course.getEnrollmentLimit());
        dto.setSchedule(course.getSchedule());
        dto.setRoomNum(course.getRoomNum());
        dto.setDescription(course.getDescription());
        dto.setEnrolledCount(enrolledCount);
        dto.setSeatsLeft(Math.max(0, course.getEnrollmentLimit() - enrolledCount));
        dto.setEnrolled(enrolled);
        dto.setRegistrationId(registrationId);
        return dto;
    }

    public RegistrationDto toRegistrationDto(Registration registration) {
        String date = registration.getRegistrationDate() == null ? "" : registration.getRegistrationDate().toString();
        return new RegistrationDto(
                String.valueOf(registration.getRegistrationId()),
                registration.getStudent().getStudentId(),
                toCourseDto(registration.getCourse(), "ENROLLED".equals(registration.getStatus()), String.valueOf(registration.getRegistrationId())),
                registration.getSemester(),
                date,
                registration.getStatus()
        );
    }

    public TransactionDto toTransactionDto(Transaction transaction) {
        return new TransactionDto(
                String.valueOf(transaction.getTransactionId()),
                transaction.getType(),
                transaction.getDescription(),
                transaction.getDate() == null ? "" : transaction.getDate().toString(),
                transaction.getAmount()
        );
    }

    public StudentDto toStudentDto(Student student) {
        List<RegistrationDto> registrations = registrationRepository.findByStudent(student)
                .stream()
                .filter(r -> "ENROLLED".equals(r.getStatus()))
                .map(this::toRegistrationDto)
                .toList();

        Account account = accountRepository.findByStudent(student).orElse(null);

        StudentDto dto = new StudentDto();
        dto.setStudentId(student.getStudentId());
        dto.setName(student.getUser().getName());
        dto.setUsername(student.getUser().getUsername());
        dto.setMajor(student.getMajor());
        dto.setAvatar(initials(student.getUser().getName()));
        dto.setCreditHours(registrations.stream().mapToInt(r -> r.getCourse().getCourseHours()).sum());
        dto.setEnrollments(registrations.size());
        dto.setRegistrations(registrations);

        if (account != null) {
            dto.setBalance(account.getCurrentBalance());
            dto.setTotalCharges(account.getTotalCharges());
            dto.setTotalPayments(account.getTotalPayments());
            dto.setLastPaymentDate(transactionRepository.findByAccountOrderByDateDescTransactionIdDesc(account)
                    .stream()
                    .filter(t -> "PAYMENT".equals(t.getType()))
                    .map(t -> t.getDate() == null ? "" : t.getDate().toString())
                    .findFirst()
                    .orElse(""));
        }
        return dto;
    }

    public AccountDto toAccountDto(Account account) {
        AccountDto dto = new AccountDto();
        dto.setAccountId(String.valueOf(account.getAccountId()));
        dto.setStudent(toStudentDto(account.getStudent()));
        dto.setCurrentBalance(account.getCurrentBalance());
        dto.setTotalCharges(account.getTotalCharges());
        dto.setTotalPayments(account.getTotalPayments());
        dto.setDueDate(account.getDueDate() == null ? "" : account.getDueDate().toString());
        dto.setTransactions(transactionRepository.findByAccountOrderByDateDescTransactionIdDesc(account)
                .stream()
                .sorted(Comparator.comparing(Transaction::getDate, Comparator.nullsLast(Comparator.reverseOrder()))
                        .thenComparing(Transaction::getTransactionId, Comparator.nullsLast(Comparator.reverseOrder())))
                .map(this::toTransactionDto)
                .toList());
        return dto;
    }

    private String initials(String name) {
        if (name == null || name.isBlank()) return "SM";
        String[] parts = name.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase();
        return ("" + parts[0].charAt(0) + parts[1].charAt(0)).toUpperCase();
    }
}
