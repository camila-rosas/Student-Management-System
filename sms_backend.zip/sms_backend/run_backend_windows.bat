@echo off
echo Starting Student Management System Java Backend...
echo Make sure XAMPP MySQL is running first.
gradlew.bat bootRun
pause
