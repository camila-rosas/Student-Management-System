-- Optional XAMPP/phpMyAdmin setup script.
-- The Spring Boot connection string can also create this database automatically.
CREATE DATABASE IF NOT EXISTS smsdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smsdb;
