#!/usr/bin/env bash
echo "Starting Student Management System Java Backend..."
echo "Make sure XAMPP MySQL is running first."
chmod +x ./gradlew
./gradlew bootRun
